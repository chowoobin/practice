$(document).ready(function(){
	// 메뉴 on off
	$(".gnb_menu li").on("click",function(){
		$(".gnb_menu li").removeClass('on');
		$(this).addClass('on');
	});

	// 정의형 목록 상세내용 none, block
	$(".define_ar dl").on("click",function(){
		if($(".define_ar dl").hasClass('on')){
			if($(this).hasClass('on')){
				$(this).removeClass('on');
				$(this).find('.code_ex').removeClass('on');
			} else{
				$(".define_ar dl").removeClass('on');
				$('.code_ex').removeClass('on');
				$(this).addClass('on');
				$(this).find('.code_ex').addClass('on');
			}
		} else{
			$(this).addClass('on');
			$(this).find('.code_ex').addClass('on');
		}
	});

	// 모바일 메뉴 버튼
	$(".m_menu").on("click",function(){
		$(".m_gnb").animate({right:'0'},400);
	});
	$(".m_gnb .btn_menuClose").on("click",function(){
		$(".m_gnb").animate({right:'+=-85%'},400);
	});

	// 스크롤 맨 위로 올리기
	var check=false;
	$(window).scroll(function() {
		if(!check){
			if($(this).scrollTop()>200){
				$('.btn_scrollTop').fadeIn();
				$('.sidebar').fadeIn();
				check=true;
			}
		} else {
			if($(this).scrollTop() == 0){
				$('.btn_scrollTop').fadeOut();
				$('.sidebar').css('display','none');
				check=false;
			}
		}
	});
	$(".btn_scrollTop").click(function() {
		$('body').animate({scrollTop:0},400);
	});

	// 바로가기 목록
	
	
	var direct_link = function(){
		var checked = true;
		
		
		if($(".sidebar ul").is(':animated')){
				event.preventDefault();
			//	event.stopPropagation();
			//	event.preventDefault()
				return ;
			}

				// console.log(ul_height);
				// alert();
		if(checked){
			
			$(".sidebar em").on("click",function(){
				checked = false;
				var speed = 'fast',
					target = $(".sidebar em"),
					ul_height = $(".sidebar ul").outerHeight();
				
				if(!target.hasClass('on')){
					$(".sidebar ul").stop().animate({
						'top' : - ul_height
					},speed, function(){
						target.addClass('on');
						checked = true;
						console.log(checked);
					});
				}else{
					$(".sidebar ul").stop().animate({
						'top' : 0
					},speed, function(){
						target.removeClass('on');
						checked = true;
						console.log(checked);
					});
				}
			});
		}

		$(".sidebar li").click(function(){
			var ul_height02 = $(".sidebar ul").outerHeight();
			$(".sidebar em").addClass('on');
			$(".sidebar ul").css('top',-ul_height02);
		});
			
			
			// if($(".sidebar ul").is(':animated')){
			// 	event.preventDefault();
			// //	event.stopPropagation();
			// //	event.preventDefault()
			// 	//return false;
			// }
			// if(checked){
			// 	checked = false;
			// 	if(target.hasClass('on')){
			// 		$(".sidebar ul").animate({top:'-1px'},speed, function(){
			// 			target.removeClass('on');
			// 			checked = true;
			// 		});
			// 		//$(".sidebar ul").css('margin-top','-100px');
			// 	}else{
			// 		//$(".sidebar ul").css('margin-top','0');
			// 		$(".sidebar ul").animate({top:-ul_height},speed, function(){
			// 			target.addClass('on');
			// 			checked = true;
			// 		});
			// 	}
			// }

			// $(".sidebar li").click(function(){
			// 	$(".sidebar em").addClass('on');
			// 	$(".sidebar ul").css('top',-ul_height);
			// 	//$(".sidebar ul").css('margin-top','-100px');
			// });
		
	}
	direct_link();
});

